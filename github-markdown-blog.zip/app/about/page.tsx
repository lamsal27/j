import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Github, Mail, BookOpen, Code, Lightbulb } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <div className="container px-4 py-24 mx-auto">
        <div className="max-w-3xl mx-auto">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors mb-8"
          >
            <ArrowLeft className="w-4 h-4" /> Back to home
          </Link>

          <div className="flex flex-col md:flex-row gap-8 mb-12 items-center md:items-start">
            <div className="w-32 h-32 relative rounded-full overflow-hidden border-4 border-primary/20 flex-shrink-0">
              <Image
                src="/placeholder.svg?height=128&width=128"
                alt="Siddhartha Lamsal"
                fill
                className="object-cover"
              />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">About Me</h1>
              <p className="text-xl font-medium mb-6 text-primary">
                Siddhartha Lamsal — Student, Learner, Programming & Technology Enthusiast
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="https://github.com/lamsal27" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="gap-2">
                    <Github className="w-4 h-4" /> GitHub
                  </Button>
                </Link>
                <Button variant="outline" size="sm" className="gap-2">
                  <Mail className="w-4 h-4" /> Contact Me
                </Button>
              </div>
            </div>
          </div>

          <div className="prose prose-lg dark:prose-invert max-w-none">
            <h2 className="flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-primary" />
              My Journey
            </h2>
            <p>
              I'm passionate about learning and exploring new concepts in programming and technology. As a student, I'm
              constantly challenging myself to grow and expand my knowledge.
            </p>
            <p>
              This website serves as a platform for me to document my journey, share my projects, and connect with
              others who share similar interests.
            </p>

            <h2 className="flex items-center gap-2">
              <Code className="w-5 h-5 text-primary" />
              What I'm Interested In
            </h2>
            <ul>
              <li>Programming languages and paradigms</li>
              <li>Blockchain and cryptocurrency</li>
              <li>Artificial intelligence and machine learning</li>
              <li>Web development and software engineering</li>
              <li>Cloud computing and databases</li>
              <li>Open source contributions</li>
            </ul>

            <h2 className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary" />
              About This Blog
            </h2>
            <p>
              This blog is powered by Next.js and fetches content directly from my GitHub repository at{" "}
              <a href="https://github.com/lamsal27/blogs" target="_blank" rel="noopener noreferrer">
                lamsal27/blogs
              </a>
              . It showcases various markdown files covering different technology topics.
            </p>
            <p>
              The content is automatically updated whenever I push new markdown files to the repository, making it easy
              to maintain and expand.
            </p>

            <h2>Let's Connect</h2>
            <p>
              I'm always open to discussions, collaborations, or just chatting about shared interests. Feel free to
              reach out through any of the platforms linked above.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

