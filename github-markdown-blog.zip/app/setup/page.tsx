"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Github } from "lucide-react"

export default function SetupPage() {
  const [formData, setFormData] = useState({
    githubUsername: "lamsal27",
    githubRepo: "blogs",
    githubBranch: "main",
    contentPath: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // In a real app, this would save to .env.local or a database
    // For now, we'll just show the configuration
    alert(`
      Add these to your .env.local file:
      
      GITHUB_USERNAME=${formData.githubUsername}
      GITHUB_REPO=${formData.githubRepo}
      GITHUB_BRANCH=${formData.githubBranch}
      CONTENT_PATH=${formData.contentPath}
    `)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-2 mb-2">
            <Github className="w-5 h-5" />
            <span className="font-semibold">Lamsal Writes</span>
          </div>
          <CardTitle className="text-2xl">Setup Your Blog</CardTitle>
          <CardDescription>Configure your GitHub repository to fetch blog posts</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="githubUsername">GitHub Username</Label>
              <Input
                id="githubUsername"
                name="githubUsername"
                placeholder="lamsal27"
                value={formData.githubUsername}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="githubRepo">GitHub Repository</Label>
              <Input
                id="githubRepo"
                name="githubRepo"
                placeholder="blogs"
                value={formData.githubRepo}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="githubBranch">GitHub Branch</Label>
              <Input
                id="githubBranch"
                name="githubBranch"
                placeholder="main"
                value={formData.githubBranch}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contentPath">Content Path (Optional)</Label>
              <Input
                id="contentPath"
                name="contentPath"
                placeholder="Leave empty for root directory"
                value={formData.contentPath}
                onChange={handleChange}
              />
              <p className="text-xs text-muted-foreground">
                The folder in your repository where markdown files are stored (leave empty if files are in the root)
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full">
              Save Configuration
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

