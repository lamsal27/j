import Link from "next/link"
import { ArrowRight, BookOpen, Code, Lightbulb } from "lucide-react"
import BlogList from "@/components/blog-list"
import { fetchBlogPosts } from "@/lib/github"
import { Button } from "@/components/ui/button"

export default async function Home() {
  const posts = await fetchBlogPosts()

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <div className="container px-4 py-24 mx-auto">
        <header className="max-w-3xl mx-auto text-center mb-20">
          <div className="inline-block p-2 bg-primary/10 rounded-full mb-4">
            <Lightbulb className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
            <span className="text-primary">Lamsal</span> Writes
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            Thoughts, projects, and explorations in technology and programming
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/about">
              <Button variant="outline" className="gap-2">
                About Me <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="https://github.com/lamsal27/blogs" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="gap-2">
                View Repository <Code className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </header>

        <div className="max-w-3xl mx-auto mb-16">
          <div className="bg-card rounded-lg p-6 border shadow-sm">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary" />
              Welcome to My Digital Space
            </h2>
            <p className="text-muted-foreground mb-4">
              I'm Siddhartha Lamsal, a student and enthusiast in programming and technology. This blog showcases various
              topics from my GitHub repository.
            </p>
            <p className="text-muted-foreground">
              Browse through my articles below to explore topics I'm passionate about.
            </p>
          </div>
        </div>

        <BlogList posts={posts} />
      </div>
    </div>
  )
}

