import { type NextRequest, NextResponse } from "next/server"
import { revalidatePath } from "next/cache"

// This is a simple API route that can be called to revalidate the cache
// You can set up a GitHub webhook to call this endpoint when you push new content
export async function POST(request: NextRequest) {
  try {
    // You can add authentication here to ensure only authorized requests can revalidate
    const secret = request.headers.get("x-webhook-secret")
    const expectedSecret = process.env.WEBHOOK_SECRET

    if (secret !== expectedSecret) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    // Revalidate the blog pages
    revalidatePath("/")
    revalidatePath("/blog/[slug]")

    return NextResponse.json({
      revalidated: true,
      now: Date.now(),
      message: "Successfully revalidated blog content from lamsal27/blogs repository",
    })
  } catch (error) {
    return NextResponse.json({ message: "Error revalidating", error }, { status: 500 })
  }
}

