import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// This middleware ensures environment variables are available
// and redirects to a setup page if they're not configured
export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Skip API routes and static files
  if (pathname.startsWith("/api") || pathname.includes(".") || pathname.startsWith("/_next")) {
    return NextResponse.next()
  }

  // Check if GitHub configuration is set up
  const githubUsername = process.env.GITHUB_USERNAME
  const githubRepo = process.env.GITHUB_REPO

  // If GitHub configuration is missing and not on the setup page, redirect to setup
  if ((!githubUsername || !githubRepo) && pathname !== "/setup") {
    return NextResponse.redirect(new URL("/setup", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
}

