import type { BlogPost } from "./types"
import matter from "gray-matter"
import { calculateReadingTime } from "./utils"
import { markdownToHtml } from "./markdown"

// Use the environment variables
const GITHUB_USERNAME = process.env.GITHUB_USERNAME || "lamsal27"
const GITHUB_REPO = process.env.GITHUB_REPO || "blogs"
const GITHUB_BRANCH = process.env.GITHUB_BRANCH || "main"
const CONTENT_PATH = process.env.CONTENT_PATH || ""

// GitHub API endpoints
const GITHUB_API_URL = "https://api.github.com"
const GITHUB_RAW_CONTENT_URL = `https://raw.githubusercontent.com/${GITHUB_USERNAME}/${GITHUB_REPO}/${GITHUB_BRANCH}`

/**
 * Fetch all markdown files from the GitHub repository
 */
export async function fetchBlogPosts(): Promise<BlogPost[]> {
  try {
    console.log(`Fetching blog posts from GitHub: ${GITHUB_USERNAME}/${GITHUB_REPO}`)

    // Prepare headers
    const headers: HeadersInit = {
      Accept: "application/vnd.github.v3+json",
      "User-Agent": "NextJS-Blog",
    }

    // Add GitHub token if available
    if (process.env.GITHUB_TOKEN) {
      headers.Authorization = `token ${process.env.GITHUB_TOKEN}`
    }

    // Fetch all files in the repository
    const response = await fetch(
      `${GITHUB_API_URL}/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/contents${CONTENT_PATH ? `/${CONTENT_PATH}` : ""}`,
      { headers },
    )

    if (!response.ok) {
      console.error(`GitHub API error: ${response.status} ${response.statusText}`)
      return []
    }

    const files = await response.json()

    // Filter for markdown files only
    const markdownFiles = files.filter(
      (file: any) =>
        file.type === "file" && file.name.endsWith(".md") && file.name !== "README.md" && file.name !== "LICENSE",
    )

    console.log(`Found ${markdownFiles.length} Markdown files`)

    // Fetch and parse each markdown file
    const posts = await Promise.all(
      markdownFiles.map(async (file: any) => {
        try {
          const content = await fetchFileContent(file.path)
          return parseMarkdownContent(content, file.name)
        } catch (error) {
          console.error(`Error processing file ${file.name}:`, error)
          return null
        }
      }),
    )

    // Filter out any null results and sort posts by date
    return posts
      .filter((post): post is BlogPost => post !== null)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  } catch (error) {
    console.error("Error fetching blog posts:", error)
    return []
  }
}

/**
 * Fetch a specific blog post by slug
 */
export async function fetchBlogPost(slug: string): Promise<BlogPost | null> {
  try {
    const posts = await fetchBlogPosts()
    return posts.find((post) => post.slug === slug) || null
  } catch (error) {
    console.error(`Error fetching blog post ${slug}:`, error)
    return null
  }
}

/**
 * Fetch the content of a file from GitHub
 */
async function fetchFileContent(path: string): Promise<string> {
  const headers: HeadersInit = {
    "User-Agent": "NextJS-Blog",
  }

  if (process.env.GITHUB_TOKEN) {
    headers.Authorization = `token ${process.env.GITHUB_TOKEN}`
  }

  const response = await fetch(`${GITHUB_RAW_CONTENT_URL}/${path}`, { headers })

  if (!response.ok) {
    throw new Error(`Failed to fetch file content: ${response.statusText}`)
  }

  return response.text()
}

/**
 * Parse markdown content and extract frontmatter
 */
function parseMarkdownContent(content: string, filename: string): BlogPost {
  try {
    // Parse frontmatter and content
    const { data, content: markdown } = matter(content)

    // Generate slug from filename (remove .md extension)
    const slug = filename.replace(/\.md$/, "")

    // Calculate reading time
    const readingTime = calculateReadingTime(markdown)

    // Format title from filename if not in frontmatter
    const title = data.title || formatTitle(slug)

    // Generate a category from the filename
    const category = data.category || getCategoryFromFilename(filename)

    return {
      slug,
      title,
      description: data.description || extractDescription(markdown),
      date: data.date ? new Date(data.date).toISOString() : new Date().toISOString(),
      coverImage: data.coverImage || `/placeholder.svg?height=600&width=1200&text=${category}`,
      tags: data.tags || [category],
      content: markdown,
      htmlContent: markdownToHtml(markdown),
      readingTime,
      author: data.author || "Siddhartha Lamsal",
      category,
    }
  } catch (error) {
    console.error(`Error parsing markdown content for ${filename}:`, error)

    // Return a fallback post with minimal information
    return {
      slug: filename.replace(/\.md$/, ""),
      title: formatTitle(filename.replace(/\.md$/, "")),
      description: "Error parsing this post",
      date: new Date().toISOString(),
      coverImage: `/placeholder.svg?height=600&width=1200&text=Error`,
      tags: [],
      content: "There was an error processing this content.",
      htmlContent: "<p>There was an error processing this content.</p>",
      readingTime: 1,
      author: "Siddhartha Lamsal",
      category: "Uncategorized",
    }
  }
}

/**
 * Extract a description from the markdown content
 */
function extractDescription(content: string): string {
  // Remove markdown formatting and get the first 160 characters
  const plainText = content
    .replace(/#+\s+(.*)/g, "$1") // Remove headings
    .replace(/\[([^\]]+)\]$$[^)]+$$/g, "$1") // Remove links
    .replace(/\*\*([^*]+)\*\*/g, "$1") // Remove bold
    .replace(/\*([^*]+)\*/g, "$1") // Remove italic
    .replace(/`([^`]+)`/g, "$1") // Remove inline code
    .replace(/```[\s\S]*?```/g, "") // Remove code blocks
    .replace(/\n/g, " ") // Replace newlines with spaces
    .trim()

  return plainText.length > 160 ? plainText.substring(0, 157) + "..." : plainText
}

/**
 * Format a title from a slug
 */
function formatTitle(slug: string): string {
  return slug
    .split("_")
    .join(" ")
    .split("-")
    .join(" ")
    .replace(/\b\w/g, (char) => char.toUpperCase())
}

/**
 * Get a category from a filename
 */
function getCategoryFromFilename(filename: string): string {
  // Remove .md extension
  const name = filename.replace(/\.md$/, "")

  // Map of common categories
  const categoryMap: Record<string, string> = {
    ai: "AI",
    blockchain: "Blockchain",
    cloud: "Cloud",
    crypto: "Crypto",
    database: "Database",
    design: "Design",
    dev: "Development",
    education: "Education",
    framework: "Framework",
    gaming: "Gaming",
    web: "Web",
  }

  // Check if any of the category keywords are in the filename
  for (const [key, value] of Object.entries(categoryMap)) {
    if (name.toLowerCase().includes(key.toLowerCase())) {
      return value
    }
  }

  // Default category
  return "Technology"
}

