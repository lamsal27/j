export interface BlogPost {
  slug: string
  title: string
  description: string
  date: string
  coverImage: string | null
  tags: string[]
  content: string
  htmlContent: string
  readingTime: number
  author: string
  category: string
}

