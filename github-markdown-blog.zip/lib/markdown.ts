import { marked } from "marked"
import hljs from "highlight.js"

// Configure marked with syntax highlighting
marked.setOptions({
  highlight: (code, lang) => {
    if (lang && hljs.getLanguage(lang)) {
      return hljs.highlight(code, { language: lang }).value
    }
    return hljs.highlightAuto(code).value
  },
  breaks: true,
  gfm: true,
})

/**
 * Convert markdown to HTML
 */
export function markdownToHtml(markdown: string): string {
  return marked(markdown)
}

