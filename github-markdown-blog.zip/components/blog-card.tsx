import Link from "next/link"
import Image from "next/image"
import { Calendar, Clock } from "lucide-react"
import { formatDate } from "@/lib/utils"
import type { BlogPost } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface BlogCardProps {
  post: BlogPost
}

export default function BlogCard({ post }: BlogCardProps) {
  return (
    <Link href={`/blog/${post.slug}`} className="block h-full group">
      <Card className="overflow-hidden h-full transition-all duration-300 hover:shadow-md hover:border-primary/20">
        <div className="relative aspect-video overflow-hidden">
          <Image
            src={post.coverImage || `/placeholder.svg?height=400&width=600&text=${post.category}`}
            alt={post.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute top-2 right-2 z-10">
            <Badge variant="secondary" className="text-xs font-normal">
              {post.category}
            </Badge>
          </div>
        </div>
        <CardContent className="p-6">
          <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>{formatDate(post.date)}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>{post.readingTime} min read</span>
            </div>
          </div>
          <h3 className="text-xl font-semibold mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {post.title}
          </h3>
          <p className="text-muted-foreground line-clamp-3">{post.description}</p>
        </CardContent>
      </Card>
    </Link>
  )
}

