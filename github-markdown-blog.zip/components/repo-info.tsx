import { Github, GitBranch, FileText } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface RepoInfoProps {
  username: string
  repo: string
  branch: string
  contentPath: string
}

export default function RepoInfo({ username, repo, branch, contentPath }: RepoInfoProps) {
  return (
    <Card className="mb-12">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Github className="w-5 h-5" />
          Repository Information
        </CardTitle>
        <CardDescription>Blog content is fetched from the following GitHub repository</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            <Github className="w-4 h-4 text-muted-foreground" />
            <span className="font-medium">Repository:</span>
            <a
              href={`https://github.com/${username}/${repo}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              {username}/{repo}
            </a>
          </div>
          <div className="flex items-center gap-2">
            <GitBranch className="w-4 h-4 text-muted-foreground" />
            <span className="font-medium">Branch:</span>
            <span>{branch}</span>
          </div>
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-muted-foreground" />
            <span className="font-medium">Content Path:</span>
            <span>{contentPath || "Root directory"}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

