"use client"

import { useEffect } from "react"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"
import rehypeRaw from "rehype-raw"
import rehypePrism from "rehype-prism-plus"
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter"
import { vscDarkPlus } from "react-syntax-highlighter/dist/cjs/styles/prism"
import Image from "next/image"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface MarkdownRendererProps {
  content: string
}

export default function MarkdownRenderer({ content }: MarkdownRendererProps) {
  useEffect(() => {
    // Add Prism.js highlighting
    if (typeof window !== "undefined") {
      const Prism = require("prismjs")
      Prism.highlightAll()
    }
  }, [content])

  if (!content || content.trim() === "") {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>No content available for this post.</AlertDescription>
      </Alert>
    )
  }

  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      rehypePlugins={[rehypeRaw, rehypePrism]}
      components={{
        img: ({ node, ...props }) => {
          const src = props.src || ""
          const alt = props.alt || ""

          // Handle relative image paths by prepending the GitHub raw content URL
          const imageSrc = src.startsWith("http")
            ? src
            : `https://raw.githubusercontent.com/${process.env.GITHUB_USERNAME || "lamsal27"}/${process.env.GITHUB_REPO || "SusHub"}/${process.env.GITHUB_BRANCH || "main"}/${src.startsWith("/") ? src.substring(1) : src}`

          return (
            <div className="relative aspect-video my-8 rounded-lg overflow-hidden">
              <Image
                src={imageSrc || "/placeholder.svg"}
                alt={alt}
                fill
                className="object-cover"
                onError={(e) => {
                  // Fallback to placeholder if image fails to load
                  ;(e.target as HTMLImageElement).src = "/placeholder.svg"
                }}
              />
            </div>
          )
        },
        a: ({ node, ...props }) => (
          <a
            {...props}
            className="text-primary hover:text-primary/80 underline underline-offset-4"
            target={props.href?.startsWith("http") ? "_blank" : undefined}
            rel={props.href?.startsWith("http") ? "noopener noreferrer" : undefined}
          />
        ),
        code: ({ node, inline, className, children, ...props }) => {
          const match = /language-(\w+)/.exec(className || "")
          return !inline && match ? (
            <SyntaxHighlighter
              style={vscDarkPlus}
              language={match[1]}
              PreTag="div"
              className="rounded-md my-6"
              {...props}
            >
              {String(children).replace(/\n$/, "")}
            </SyntaxHighlighter>
          ) : (
            <code className="bg-muted px-1.5 py-0.5 rounded text-sm" {...props}>
              {children}
            </code>
          )
        },
      }}
    >
      {content}
    </ReactMarkdown>
  )
}

